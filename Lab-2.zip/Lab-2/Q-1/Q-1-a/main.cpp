#include <bits/stdc++.h>
using namespace std;

void merge(vector<int>& a, vector<int>& b, vector<int>& c) {
    int m = a.size(), n = b.size();
    int i = 0, j = 0, k = 0;
    while(k < m + n) {
        if(j == n || a[i] <= b[j]) c[k] = a[i++];
        else if(i == m || b[j] <= a[i]) c[k] = b[j++];
        k++;
    }
}

int main() {
    int r; vector<int> a, b;

    ifstream arr_a("../../A.txt");
    while(arr_a >> r) a.push_back(r);
    sort(a.begin(), a.end());
    arr_a.close();
   
    ifstream arr_b("../../arr_b.txt");
    while(arr_b >> r) b.push_back(r);
    sort(b.begin(), b.end());
    arr_b.close();

	int m = a.size(), n = b.size();
	vector<int> c(m + n);
	merge(a, b, c);

    ofstream outputFile("output.txt");
	for(int y : c) outputFile << y << " ";
    outputFile.close();
}