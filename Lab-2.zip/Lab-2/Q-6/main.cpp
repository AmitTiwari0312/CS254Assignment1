#include <bits/stdc++.h>
using namespace std;

void median(vector<int>& a, int l, int r) {
    int m = (l+r)/2;
    if(a[r] < a[l]) swap(a[l], a[r]);     
    if(a[m] < a[l]) swap(a[m], a[l]);
    if(a[r] < a[m]) swap(a[r], a[m]);
    swap(a[m], a[r-1]);
}

int partition(vector<int>& a, int l, int r) {
    median(a, l, r);
    int x = a[r-1];
    int i = l-1, j = r;
    for(int j = l; j < r-1; ++j) 
        if(a[j] < x) swap(a[++i], a[j]);
    swap(a[i+1], a[r-1]);
    return i+1;
}

void qs(vector<int>& a, int l, int r) {
    if(r>l) {
        int p = partition(a, l, r);
        qs(a, l, p-1);
        qs(a, p+1, r);
    }
}

int main() {
    int x; vector<int> a;

    ifstream arr_a("../A.txt");
    while(arr_a >> x) a.push_back(x);
    arr_a.close();
    int n = a.size();

    qs(a, 0, n - 1);
    
    ofstream outputFile("output.txt");
    for (int x : a) outputFile << x << ' ';
    outputFile.close(); 
}