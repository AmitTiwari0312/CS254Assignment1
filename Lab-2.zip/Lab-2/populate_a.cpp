#include <bits/stdc++.h>
using namespace std;

int main() {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<int> dis(1, 1e5);  
    const int numRandomNumbers = 100000;
    ofstream arr_a("A.txt");

    if (!arr_a.is_open()) {
        cerr << "Error..." << endl;
        return 1;
    }

    for (int i = 0; i < numRandomNumbers; ++i) {
        int randomNum = dis(gen);
        arr_a << randomNum;

        if (i < numRandomNumbers - 1) {
            arr_a << ' ';
        }
    }

    arr_a.close();
    cout << "Done" << endl;

    return 0;
}
