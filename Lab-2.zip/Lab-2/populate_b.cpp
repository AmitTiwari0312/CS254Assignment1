#include <bits/stdc++.h>
using namespace std;

int main() {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<int> dis(1, 1e5);  // Change the range as needed
    const int N = 100000;
    ofstream arr_b("B.txt");

    if (!arr_b.is_open()) {
        cerr << "Error..." << endl;
        return 1;
    }

    for (int i = 0; i < N; ++i) {
        int randomNum = dis(gen);
        arr_b << randomNum;

        if (i < N - 1) {
            arr_b << ' ';
        }
    }

    arr_b.close();
    cout << "Done" << endl;

    return 0;
}
