#include<bits/stdc++.h>
using namespace std;

const string OUTPUT_FILE_NAME = "output.txt";

// add two matrices
void add(vector< vector<int> > &mxA, 
         vector< vector<int> > &mxB, 
         vector< vector<int> > &mxC, unsigned int mSize) {
    for (int i = 0; i < mSize; i++) {
        for (int j = 0; j < mSize; j++) {
            mxC[i][j] = mxA[i][j] + mxB[i][j];
        }
    }
}

// subtract two matrices
void sub(vector< vector<int> > &mxA, 
        vector< vector<int> > &mxB, 
        vector< vector<int> > &mxC, unsigned int mSize) {
    for (int i = 0; i < mSize; i++) {
        for (int j = 0; j < mSize; j++) {
            mxC[i][j] = mxA[i][j] - mxB[i][j];
        }
    }   
}

// write mx to output file
void writeToFile(vector< vector<int> > &mxC, unsigned int mSize) {
    ofstream outputFile;
    outputFile.open(OUTPUT_FILE_NAME);
    for (int i = 0; i < mSize; i++) {
        for (int j = 0; j < mSize; j++) {
            outputFile << mxC[i][j] << " ";
        }
        outputFile << "\n";
    }
    outputFile.close();
}

// print a mx to the console
void printmx(vector< vector<int> > &mx, unsigned int mSize) {
    for (int i = 0; i < mSize; i++) {
        for (int j = 0; j < mSize; j++) {
            cout << mx[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

// recursive strassen mx multiplier
void strassenR(vector< vector<int> > &mxA,
            vector< vector<int> > &mxB,
            vector< vector<int> > &mxC,
            unsigned int mSize) {

    // recursive base case
    if (mSize == 1) {
        mxC[0][0] = mxA[0][0] * mxB[0][0];
        return;
    }
    else {
        int newMSize = mSize / 2;
        vector<int> innerVector(newMSize, 0);

        // initialize matrices
        vector< vector<int> > mxA11(newMSize, innerVector),
                            mxA12(newMSize, innerVector),
                            mxA21(newMSize, innerVector),
                            mxA22(newMSize, innerVector),
                            mxB11(newMSize, innerVector),
                            mxB12(newMSize, innerVector),
                            mxB21(newMSize, innerVector),
                            mxB22(newMSize, innerVector),
                            mxC11(newMSize, innerVector),
                            mxC12(newMSize, innerVector),
                            mxC21(newMSize, innerVector),
                            mxC22(newMSize, innerVector),
                            s1(newMSize, innerVector),
                            s2(newMSize, innerVector),
                            s3(newMSize, innerVector),
                            s4(newMSize, innerVector),
                            s5(newMSize, innerVector),
                            s6(newMSize, innerVector),
                            s7(newMSize, innerVector),
                            s8(newMSize, innerVector),
                            s9(newMSize, innerVector),
                            s10(newMSize, innerVector),
                            p1(newMSize, innerVector),
                            p2(newMSize, innerVector),
                            p3(newMSize, innerVector),
                            p4(newMSize, innerVector),
                            p5(newMSize, innerVector),
                            p6(newMSize, innerVector),
                            p7(newMSize, innerVector),
                            tempmxA(newMSize, innerVector),
                            tempmxB(newMSize, innerVector);

        // divide matrices into 4 submatrices
        for (int i = 0; i < newMSize; i++) {
            for (int j = 0; j < newMSize; j++) {
                mxA11[i][j] = mxA[i][j];
                mxA12[i][j] = mxA[i][j + newMSize];
                mxA21[i][j] = mxA[i + newMSize][j];
                mxA22[i][j] = mxA[i + newMSize][j + newMSize];

                mxB11[i][j] = mxB[i][j];
                mxB12[i][j] = mxB[i][j + newMSize];
                mxB21[i][j] = mxB[i + newMSize][j];
                mxB22[i][j] = mxB[i + newMSize][j + newMSize];
            }
        }

        // s1 = b12 - b22
        sub(mxB12, mxB22, s1, newMSize);
        
        // s2 = a11 + a12
        add(mxA11, mxA12, s2, newMSize);

        // s3 = a21 + a22
        add(mxA21, mxA22, s3, newMSize);

        // s4 = b21 - b11
        sub(mxB21, mxB11, s4, newMSize);
        
        // s5 = a11 + a22
        add(mxA11, mxA22, s5, newMSize);
        
        // s6 = b11 + b22
        add(mxB11, mxB22, s6, newMSize);

        // s7 = a12 - a22
        sub(mxA12, mxA22, s7, newMSize);

        // s8 = b21 + b22
        add(mxB21, mxB22, s8, newMSize);

        // s9 = a11 - a21
        sub(mxA11, mxA21, s9, newMSize);

        // s10 = b11 + b12
        add(mxB11, mxB12, s10, newMSize);

        // p1 = a11 * s1
        strassenR(mxA11, s1, p1, newMSize);

        // p2 = s2 * b22
        strassenR(s2, mxB22, p2, newMSize);

        // p3 = s3 * b11
        strassenR(s3, mxB11, p3, newMSize);

        // p4 = a22 * s4
        strassenR(mxA22, s4, p4, newMSize);

        // p5 = s5 * s6
        strassenR(s5, s6, p5, newMSize); 

        // p6 = s7 * s8
        strassenR(s7, s8, p6, newMSize);

        // p7 = s9 * s10
        strassenR(s9, s10, p7, newMSize);

        // c11 = p5 + p4 - p2 + p6
        add(p5, p4, tempmxA, newMSize); // p5 + p4
        add(tempmxA, p6, tempmxB, newMSize); // (p5 + p4) + p6
        sub(tempmxB, p2, mxC11, newMSize); // (p5 + p4 + p6) - p2

        // c12 = p1 + p2
        add(p1, p2, mxC12, newMSize);

        // c21 = p3 + p4
        add(p3, p4, mxC21, newMSize);

        // c22 = p5 + p1 - p3 + p7
        add(p5, p1, tempmxA, newMSize); // p5 + p1
        sub(tempmxA, p3, tempmxB, newMSize); // (p5 + p1) - p3
        sub(tempmxB, p7, mxC22, newMSize); // (p5 + p1 - p3) - p7

        // group into mxC
        for (int i = 0; i < newMSize ; i++) {
            for (int j = 0 ; j < newMSize ; j++) {
                mxC[i][j] = mxC11[i][j];
                mxC[i][j + newMSize] = mxC12[i][j];
                mxC[i + newMSize][j] = mxC21[i][j];
                mxC[i + newMSize][j + newMSize] = mxC22[i][j];
            }
        }

        // print s values to console for matrices of n = 2
        if (mSize == 2) {
            cout << endl;
            cout << "S1: " << s1[0][0] << endl;
            cout << "S2: " << s2[0][0] << endl;
            cout << "S3: " << s3[0][0] << endl;
            cout << "S4: " << s4[0][0] << endl;
            cout << "S5: " << s5[0][0] << endl;
            cout << "S6: " << s6[0][0] << endl;
            cout << "S7: " << s7[0][0] << endl;
            cout << "S8: " << s8[0][0] << endl;
            cout << "S9: " << s9[0][0] << endl;
            cout << "S10: " << s10[0][0] << endl;
        }
    }
}

// call recursive function
void strassen(vector< vector<int> > &mxA, 
              vector< vector<int> > &mxB, 
              vector< vector<int> > &mxC,
              unsigned int mSize) {
    strassenR(mxA, mxB, mxC, mSize);
}

int main() {
    unsigned int mxSize;
    ifstream inputFile;
    string inputFileName;

    // get the file name from user
    cout << "Input file name: ";
    cin >> inputFileName;
    inputFile.open(inputFileName);

    // get the size of the mx from first line of input file
    if (inputFile.is_open()) {
        string firstLine;
        getline(inputFile, firstLine);
        mxSize = stoi(firstLine);
    }

    // validate mx size constraints
    if (mxSize < 1 || mxSize > 256) {
        cout << endl << "ERROR: n must be between 1 and 256 (including 1 and 256)" << endl;
        return 0;
    } else if (ceil(log2(mxSize)) != floor(log2(mxSize))) {
        cout << endl << "ERROR: n must be a power of 2" << endl;
        return 0;
    }

    // initialize matrices
    vector< vector<int> > mxA;
    vector< vector<int> > mxB;
    vector< vector<int> > mxC(mxSize, vector<int> (mxSize, 0));
    vector<int> rowVector(mxSize);

    // populate matrices with values from input file
    if (inputFile.is_open()) {
        int lineCounter = 0; // used to keep track of current line in file
        int row = 0; // used to keep track of current row in mx
        while (!inputFile.eof()) {
            if (lineCounter < mxSize) {
                mxA.push_back(rowVector); // add a new row
                for (int col = 0; col < mxSize; col++) {
                    inputFile >> mxA[row][col];
                }
                row++;
            } else if (lineCounter == mxSize) {
                row = 0;
            } else {
                mxB.push_back(rowVector); // add a new row
                for (int col = 0; col < mxSize; col++) {
                    inputFile >> mxB[row][col];
                }
                row++;
            }
            lineCounter++; 
        }
    }
    inputFile.close();

    cout << endl << "INPUT mx A" << endl;
    printmx(mxA, mxSize);

    cout << endl << "INPUT mx B" << endl;
    printmx(mxB, mxSize);

    // run strassen mx multiplication algorithm
    strassen(mxA, mxB, mxC, mxSize);

    cout << endl << "mx C = A * B" << endl;
    printmx(mxC, mxSize);

    // write mx product to output file
    writeToFile(mxC, mxSize);

    return 0;
}
